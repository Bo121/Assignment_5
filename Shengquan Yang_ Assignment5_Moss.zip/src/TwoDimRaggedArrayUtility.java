/**
 * Class: CMSC203 
 *  Program: Assignment #5
 *  Instructor: Dr. Grinberg
 * Description: Calculate the bonus for each store
   A program that requires you to use functions to calculate the volume of a box and the    volume of a Sphere.
 * Due: 04/18/2022 
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Shengquan Yang
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility 
{
	public static double[][] readFile(File file) throws FileNotFoundException
	{
		double[][] Array = new double[10][10]; //Declare an 2-D array
		
		try
		{
			int row = 0; //Declare an integer and assign it to 0
			Scanner inputFile = new Scanner(file);//Open the file
			
			while(inputFile.hasNextLine())//Determine if the file has has line
			{
				inputFile.nextLine();//Read the line and move on
				row++;//increase the row by 1
			}
			inputFile.close();//close the file
			Array = new double[row][];//Set the number of rows for the array
			
			inputFile = new Scanner(file); //Open the file		
			
			for(int i=0; i<Array.length; i++)
			{
				String[] line = inputFile.nextLine().trim().split(" ");//Delete while spaces and white spaces in the front and in the end
				Array[i] = new double[line.length];
				
				for (int j=0; j<line.length; j++)
				{
					Array[i][j] = Double.parseDouble(line[j]);
				}
			}
			inputFile.close();
		}
		
		catch(FileNotFoundException e) 
		{
		}
		return Array;
	
	}
	
	public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException
	{
		try
		{
			PrintWriter file = new PrintWriter (outputFile);
			for (int i=0; i<data.length; i++)
			{
				for (int j=0; j<data[i].length; j++)
				{
					file.print(data[i][j] + " ");
				}
				file.println();
			}
			file.close();
		}
		
		catch (FileNotFoundException e)
		{
		}
	}
	
	public static double getTotal(double[][] data)
	{
		double total = 0.0;//Declare a double and assign it to 0.0
		
		for(int i = 0; i<data.length; i++)//Declare an integer and assign it to 0, if i is smaller than the number of the rows, increase i by 1
		{
			for (int j=0; j<data[i].length; j++)//Declare an integer and assign it to 0, if j is smaller than the number of the columns, increase j by 1
			{
				total += data[i][j];//Add the values together
			}
		}
		
		return total;//Return the total of the array
		
	}
	
	public static double getAverage(double[][] data)
	{
		double total = 0.0;//Declare a double and assign it to 0.0
		double average = 0.0;//Declare a double and assign it to 0.0
		int count = 0;//Declare a integer and assign it to 0
		
		for(int i = 0; i<data.length; i++)//Declare an integer and assign it to 0, if i is smaller than the number of the rows, increase i by 1
		{
			for (int j=0; j<data[i].length; j++)//Declare an integer and assign it to 0, if j is smaller than the number of the columns, increase j by 1
			{
				total += data[i][j];//Get the total value of these numbers
				count ++;//Count the number of these numbers
			}
		}
		
		average = (double)total/count;//Get average
		
		return average;//Return the average
		
	}
	
	public static double getRowTotal(double[][] data, int row)
	{
		double total = 0.0;//Declare a double and assign it to 0.0
		
		for (int i = 0; i < data[row].length; i++)//Declare an integer and assign it to 0, if i is smaller than the number of the columns, increase i by 1
		{
			total += data[row][i];//Get the total value of the row
		}
		
		return total;//Return total
		
	}
	
	public static double getColumnTotal(double[][] data, int col)
	{
		double total = 0.0;//Declare a double and assign it to 0.0
		try
		{
			for (int i = 0; i < data.length; i++)//Declare an integer and assign it to 0, if i is smaller than the number of the rows, increase i by 1
			{
				if(col < data[i].length)
					total += data[i][col];
			}
		}
		catch (ArrayIndexOutOfBoundsException e)
		{
		}

		return total;//Return total
		
	}
	
	public static double getHighestInRow(double[][] data, int row)
	{
		double highest = data[row][0];
		for (int i=0; i<data[row].length; i++)
		{
			if (data[row][i] > highest)
			{
				highest = data[row][i];
			}
		}
		
		return highest;
		
	}
	
	public static int getHighestInRowIndex(double[][] data, int row)
	{
		int highest_index = 0;
		double highest = data[row][0];
		for (int i=0; i<data[row].length; i++)
		{
			if (data[row][i] > highest)
			{
				highest = data[row][i];
				highest_index = i;
			}
		}
		
		return highest_index;
		
	}
	
	public static double getLowestInRow(double[][] data, int row)
	{
		double lowest = data[row][0];
		for (int i=0; i<data[row].length; i++)
		{
			if (data[row][i] < lowest)
			{
				lowest = data[row][i];
			}
		}
		
		return lowest;
		
	}
	
	public static int getLowestInRowIndex(double[][] data, int row)
	{
		int lowest_index = 0;
		double lowest = data[row][0];
		for (int i=0; i<data[row].length; i++)
		{
			if (data[row][i] < lowest)
			{
				lowest = data[row][i];
				lowest_index = i;
			}
		}
		
		return lowest_index;
		
	}
	
	public static double getHighestInColumn(double[][] data, int col)
	{
		int i=0;
		double highest=0.0;

		for(;i<data.length;i++)
		{
			try 
			{
				highest = data[i][col];
				break;
			}
			catch (ArrayIndexOutOfBoundsException e)
			{			
			}	
		}
		
		for (int j=i; j<data.length; j++)
		{
			if(col<data[j].length)//Make sure the value of the column is smaller than the number of the column of the array
			{
				if (data[j][col] > highest)//If the value is larger than the value of lowest	
				{
					highest = data[j][col];//Assign highest to the value
				}
			}		
		}
		return highest;//Return highest's value
		
	}
	
	public static int getHighestInColumnIndex(double[][] data, int col)
	{
		int highest_index = 0;//Declare an integer and assign it to 0
		int i=0;
		double highest=0.0;

		for(; i<data.length;i++)
		{
			try 
			{
				highest = data[i][col];
				break;
			}
			catch (ArrayIndexOutOfBoundsException e)
			{	
			}
			
		}
		
		for (int j=i; j<data.length; j++)
		{
			if (col < data[j].length)//Make sure the value of the column is smaller than the number of the column of the array
			{
				if (data[j][col] > highest)	//If the value is larger than the value of lowest	
				{
					highest = data[j][col];//Assign highest to the value
					highest_index = j;//Assign the index to the number of the row to get the index
				}	
			}
		}
		
		
		return highest_index;//Return the index of the value of the highest in the column
		
	}
	
	public static double getLowestInColumn(double[][] data, int col)
	{
		
		int i=0;
		double lowest=0.0;

		for(;i<data.length;i++)
		{
			try 
			{
				lowest = data[i][col];
				break;
			}
			catch (ArrayIndexOutOfBoundsException e)
			{			
			}	
		}
		for (int j=i; j<data.length; j++)
		{
			if (col < data[j].length)//Make sure the value of the column is smaller than the number of the column of the array
			{
				if (data[j][col] < lowest)//If the value is smaller than the value of lowest	
				{
					lowest = data[j][col];//Assign lowest to the value
				}
			}
		}
		
		

		return lowest;//Return the lowest's value of the column
		
	}
	
	public static int getLowestInColumnIndex(double[][] data, int col)
	{
		int lowest_index = 0;//Declare an integer and assign it to 0
		int i=0;
		double lowest=0.0;

		for(; i<data.length;i++)
		{
			try 
			{
				lowest = data[i][col];
				break;
			}
			catch (ArrayIndexOutOfBoundsException e)
			{	
			}
			
		}
		
		for (int j=i; j<data.length; j++)
		{
			if (col < data[j].length)//Make sure the value of the column is smaller than the number of the column of the array
			{
				if (data[j][col] < lowest)//If the value is smaller than the value of lowest	
				{
					lowest = data[j][col];//Assign lowest to the value
					lowest_index = j;//Assign the index to the number of the row to get the index
				}	
			}
		}
		
		return lowest_index;//Return the index of the value of the lowest in the column
	}
	
	public static double getHighestInArray(double[][] data)
	{
		double highest = data[0][0];//Assign the highest value to the fist element of the array
		for (int i=0; i<data.length; i++)
		{
			for (int j=0; j<data[i].length; j++)//Determine if the array is larger than the value of highest
			{
				if(data[i][j] > highest)
				{
					highest = data[i][j];//If so, assign highest to the value of the position of the array
				}
			}
		}	
		
		return highest;//Return highest's value
		
	}
	
	public static double getLowestInArray(double[][] data)
	{
		double lowest = data[0][0];//Assign the lowest value to the fist element of the array
		for (int i=0; i<data.length; i++)
		{
			for (int j=0; j<data[i].length; j++)
			{
				if(data[i][j] < lowest)//Determine if the array is smaller than the value of lowest
				{
					lowest = data[i][j];//If so, assign lowest to the value of the position of the array
				}
			}
		}	
		
		return lowest;//Return lowest's value
		
	}
		
}
