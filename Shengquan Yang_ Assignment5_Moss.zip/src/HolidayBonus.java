
public class HolidayBonus 
{
	public static double[] calculateHolidayBonus(double[][] data, double high, double low, double other)
	{
		double[][] HolidayBonus = new double[data.length][]; //Declare a 2D array and set the row to the length of the 2D array data's row 
		for (int i = 0; i < data.length; i++) 
		{
			HolidayBonus[i] = new double [data[i].length];
			for (int j = 0; j < data[i].length; j++) 
			{
				if(data[i][j]<0) 
				{
					HolidayBonus[i][j] = 0; // If the data is less than 0, then the bonus is set to 0
					continue;
				}
				if(data[i][j]>0) 
				{
					if(data[i][j] == TwoDimRaggedArrayUtility.getHighestInColumn(data, j)&&data[i][j] == TwoDimRaggedArrayUtility.getLowestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = high; // If only one data is in that category, then the bonus is set to highest amount of bonus
					}
					if(data[i][j] == TwoDimRaggedArrayUtility.getHighestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = high; // If the data is the highest comparing to others, then the bonus is set to highest amount of bonus
					}
					if(data[i][j] == TwoDimRaggedArrayUtility.getLowestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = low; // If the data is the lowest comparing to others, then the bonus is set to lowest amount of bonus
					}
					if(data[i][j] != TwoDimRaggedArrayUtility.getLowestInColumn(data, j)&& data[i][j] != TwoDimRaggedArrayUtility.getHighestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = other; // If the data is neither the lowest nor the highest comparing to others, then the bonus is set to other amount of bonus
					}
				}
			}
		}
		
		double[] bonus = new double[data.length];
		for (int i = 0; i < HolidayBonus.length; i++) 
		{
			for (int j = 0; j < HolidayBonus[i].length; j++) 
			{
				try
				{
					bonus[i] += HolidayBonus[i][j]; //Sum up the total bonus for each store
				}
				catch (ArrayIndexOutOfBoundsException e)
				{			
				}	
			}
				
			 
		}
		return bonus;

	}
	
	public static double calculateTotalHolidayBonus(double[][] data, double high, double low, double other)
	{
		double[][] HolidayBonus = new double[data.length][]; //Declare a 2D array and set the row to the length of the 2D array data's row 
		for (int i = 0; i < data.length; i++) 
		{
			HolidayBonus[i] = new double [data[i].length];
			for (int j = 0; j < data[i].length; j++) 
			{
				if(data[i][j]<0) 
				{
					HolidayBonus[i][j] = 0; // If the data is less than 0, then the bonus is set to 0
					continue;
				}
				if(data[i][j]>0) 
				{
					if(data[i][j] == TwoDimRaggedArrayUtility.getHighestInColumn(data, j)&&data[i][j] == TwoDimRaggedArrayUtility.getLowestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = high; // If only one data is in that category, then the bonus is set to highest amount of bonus
					}
					if(data[i][j] == TwoDimRaggedArrayUtility.getHighestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = high; // If the data is the highest comparing to others, then the bonus is set to highest amount of bonus
					}
					if(data[i][j] == TwoDimRaggedArrayUtility.getLowestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = low; // If the data is the lowest comparing to others, then the bonus is set to lowest amount of bonus
					}
					if(data[i][j] != TwoDimRaggedArrayUtility.getLowestInColumn(data, j)&& data[i][j] != TwoDimRaggedArrayUtility.getHighestInColumn(data, j)) 
					{
						HolidayBonus[i][j] = other; // If the data is neither the lowest nor the highest comparing to others, then the bonus is set to other amount of bonus
					}
				}
			}
		}
		
		double totalBonus = 0.0;
		double[] bonus = new double[data.length];
		for (int i = 0; i < HolidayBonus.length; i++) 
		{
			for (int j = 0; j < HolidayBonus[i].length; j++)
			{
				bonus[i] += HolidayBonus[i][j];
			}
			totalBonus += bonus[i];
		}
		return totalBonus;
	}
}
