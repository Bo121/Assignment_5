import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class HolidayBonusTestStudent {
	
	private double[][] dataSet1 = {{3536.55, 55665.05, 31543.65, 85324.55, 43884.45, 75982.35},
									{38762.25, 45762.45, 29546.65},
									{58962.35, 38552.95, 33863.65, 64992.95},
									{32567.65, 46237.65, 52862.95, 64384.85, 47944.35},
									{41843.85, 46546.55, 44557.65, 73872.35, 52657.75, 55924.55},
									{36574.65, 42653.45, 32563.85, 99352.65, 62873.45}};
	
	@BeforeEach
	public void setUp() throws Exception {
	}

	@AfterEach
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		try{
			double[] result = HolidayBonus.calculateHolidayBonus(dataSet1,5000,1000,2000);
			assertEquals(16000.00,result[0],.001);
			assertEquals(5000.00,result[1],.001);
			assertEquals(10000.00,result[2],.001);
			assertEquals(12000.00,result[3],.001);
			assertEquals(11000.00,result[4],.001);
			assertEquals(16000.00,result[5],.001);
		}
		catch (Exception e) {
			fail("This should not have caused an Exception");
		}
	}

}
